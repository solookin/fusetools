#!/usr/bin/php
<?php
	require_once("./util.php");

	const NEWEST_URL = 'https://www.789kk.com/api/newest?code=klpk10&t=';
	const TABLENAME = "t_klpk10";

	$headers = [
		'Accept: */*',
		'Accept-Language: zh-CN,zh;q=0.9,en;q=0.8',
		'Connection: keep-alive',
		'Host: www.789kk.com',
		'Referer: https://www.789kk.com/draw-klpk10-today.html',
		'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36',
		'X-Requested-With: XMLHttpRequest'
	];

	function main() {
		while(true) {
			if (process()) {
				sleep(20); // 20秒
			} else {
				sleep(2);
			}
		}
	}

	function process() {
		global $headers;
		global $mysql;
		$t = time() . rand(100, 999);	
		$url = NEWEST_URL . $t;

		$result = curl_get_https($url, $headers); 

		$resultArr = json_decode($result, true);

		$code = $resultArr['code'];
		$message = $resultArr['message'];
		if ($code && $message != 'success') {
			return false;
		}

		$ballsArr = $resultArr['data']['newest']['array'];
		$balls = $resultArr['data']['newest']['code'];
		$id = $resultArr['data']['newest']['term'];
		$time = $resultArr['data']['newest']['time'];
		echo '期数:' . $id . " ";

		// 1、查询数据库是否有该期号
		$sql = "select count(1) num from " . TABLENAME . " where id=$id AND balls is not null";
		$result = mysqli_query($mysql, $sql);
		$exists = false;
		while($row = mysqli_fetch_row($result)) {
			$exists = $row[0];
			break;
		}
		mysqli_free_result($result);

		// 插入数据库
		$sum = 0;
		foreach($ballsArr as $i) {
			$sum += $i;
		}

		$dan = [];
		$big = [];
		foreach($ballsArr as $item) {
			if ($item % 2 == 0) {
				array_push($dan, '双');
			} else {
				array_push($dan, '单');
			}

			if ($item <= 5) {
				array_push($big, '小');	
			} else {
				array_push($big, '大');	
			}
		}

		$danStr = implode(",", $dan);
		$bigStr = implode(",", $big);
		if(! $exists) {
			$sql = "insert into " . TABLENAME . "(id, balls, time, sum, dan, big) values('$id', '$balls', '$time', $sum, '$danStr', '$bigStr')";
			echo 'sql: ' . $sql . "\n";
			mysqli_query($mysql, $sql);
			echo "插入成功\n";
		} else {
			echo "没有插入[数据重复]\n";
		}

		return true;
	}

	main();
?>
