#!/usr/bin/php
<?php
	require_once("./util.php");

	$TB = [
		't_klft' => '快乐飞艇',
		't_xyft' => '幸运飞艇',
		't_klpk10' => '快乐赛车',
	];

	function main() {
		parse('t_klft', 20);
	}

	function process() {
		global $headers;
		global $mysql;
		

		// 1、查询数据库是否有该期号
		$sql = "select count(1) num from " . TABLENAME . " where id=$id AND balls is not null";
		$result = mysqli_query($mysql, $sql);
		$exists = false;
		while($row = mysqli_fetch_row($result)) {
			$exists = $row[0];
			break;
		}
		mysqli_free_result($result);

		// 插入数据库
		$sum = 0;
		foreach($ballsArr as $i) {
			$sum += $i;
		}

		$dan = [];
		$big = [];
		foreach($ballsArr as $item) {
			if ($item % 2 == 0) {
				array_push($dan, '双');
			} else {
				array_push($dan, '单');
			}

			if ($item <= 5) {
				array_push($big, '小');	
			} else {
				array_push($big, '大');	
			}
		}

		$danStr = implode(",", $dan);
		$bigStr = implode(",", $big);
		if(! $exists) {
			$sql = "insert into " . TABLENAME . "(id, balls, time, sum, dan, big) values('$id', '$balls', '$time', $sum, '$danStr', '$bigStr')";
			echo 'sql: ' . $sql . "\n";
			mysqli_query($mysql, $sql);
			echo "插入成功\n";
		} else {
			echo "没有插入[数据重复]\n";
		}

		return true;
	}

	main();

	function parse($tablename, $num) {
		global $mysql;

		// 1、先从数据库里面取倒数10条数据
		$sql = "select big, dan from $tablename order by id desc limit $num";
		$result = $mysql->query($sql);

		$dan = [];
		$big = [];
		while($row = mysqli_fetch_row($result)) {
			$b = $row[0];
			$d = $row[1];

			$b_tmp = explode(',', $b);
			array_push($big, $b_tmp);

			$d_tmp = explode(',', $d);
			array_push($dan, $d_tmp);
		}
		mysqli_free_result($result);

		// 2、分析数据
		foreach($big as $b) {
			foreach($b as $bb) {
				echo "$bb ";
			}
			echo "\n";
		}

		echo "\n";
		foreach($dan as $d) {
			foreach($d as $dd) {
				echo "$dd ";
			}
			echo "\n";
		}

		for($i = 0; $i < 10; $i++) {
			for($j = 0; $j < 10; $j++) {
				
			}
		}
	}
?>
