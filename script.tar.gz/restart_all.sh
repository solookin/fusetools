#!/bin/bash


ps aux | grep klft.php | grep -v grep | awk '{print $2}' | xargs kill -9
nohup ./klft.php > /dev/null &

ps aux | grep klpk10.php | grep -v grep | awk '{print $2}' | xargs kill -9
nohup ./klpk10.php > /dev/null &

ps aux | grep xyft.php | grep -v grep | awk '{print $2}' | xargs kill -9
nohup ./xyft.php > /dev/null &

