<?php
	include('./simplehtmldom/simple_html_dom.php');

	$mysql_servername = "127.0.0.1";
	$mysql_username = "root";
	$mysql_passwd = "peipei2016";
	$mysql_db = "db_caipiao";
	$mysql_charset = "utf8";
	$mysql = mysqli_connect($mysql_servername, $mysql_username, $mysql_passwd, $mysql_db); 
	if ( ! $mysql) {
		write_log("connect to mysql failed: " . mysqli_connect_error());
		die();
	} else {
		//write_log("connect to mysql success.");
	}
?>
