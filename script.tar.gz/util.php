<?php 
	ini_set('display_errors','On');
	date_default_timezone_set("Asia/Shanghai");

	require_once('common.php');

	function curl_get($url){
		$ch = curl_init();
		$timeout = 5; 
		$user_agent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.1.4322)";
		curl_setopt($ch, CURLOPT_URL, $url);        //设置url
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);   //设置开启重定向支持
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
		curl_setopt($ch, CURLOPT_USERAGENT, $user_agent); // 模拟用户使用的浏览器
		$output = curl_exec($ch);  //执行
		curl_close($ch);
		return $output;
	}

	//写入日志文件
	function write_log($msg='',$log_name='log.txt'){
			$handle = fopen("./logs/".$log_name, "a+");
			$text = date("Y-m-d H:i:s")." ".$msg."\r\n";
			fwrite($handle,$text);
			fclose($handle);

			echo $msg . "\n";
	}

	function curl_get_https($url, $headEx=array(), $cookiePath = './1.cookie') {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);

		if(!empty($cookiePath)){
			curl_setopt($ch, CURLOPT_COOKIEJAR, $cookiePath); //保存cookie
			curl_setopt($ch, CURLOPT_COOKIEFILE, $cookiePath); //访问带上cookie
		}   

		//显示请求头
		curl_setopt($ch, CURLINFO_HEADER_OUT, false);
		curl_setopt($ch, CURLOPT_HEADER, false);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headEx);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3); 
		curl_setopt($ch, CURLOPT_TIMEOUT , 5); 
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0); 
		$file_contents = curl_exec($ch);

		curl_close($ch);
		return $file_contents;
	}
?>
