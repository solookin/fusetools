from src import userinfo as userinfo
from src import jisu_11_5 as jisu_11_5
from src import util as util

if __name__ == '__main__':
    print("OK")
    # util.getVerifyCode()

    # util.login('9922')
    import json
    jsonData = "{'a'='b'}"

    text = json.loads(jsonData, )
    print(text)
