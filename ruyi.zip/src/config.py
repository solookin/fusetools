URLS = {
    'HOST': 'http://www.ry399.com',
    'GET_USER_MSG': '/user/getUserMsg.do',  # 获取用户信息
    'GET_VERIFY_CODE': '/api/getValidateCode.do',  # 获取验证码
    'GET_MAINTAIN_INFO': '/static/data/maintainInfo.json',  # 获取服务器维护信息
    'LOGIN': '/api/login.do',
}

Headers = {
    'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 8.0.0; DUK-AL20 Build/HUAWEIDUK-AL20)',
    #'Accept-Encoding': 'gzip',
    #'Content-Type': 'application/x-www-form-urlencoded'
    'Host': 'www.ry399.com'
}

UserInfo = {}
