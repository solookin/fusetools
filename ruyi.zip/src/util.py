import time
import requests
import re
import pickle
from urllib.parse import urlencode
from requests.cookies import RequestsCookieJar
import json

from src import config as config

test = True

session = requests.session()


def getTimeStamp():
    t = time.time()
    t = str(t)
    pointIndex = t.find('.')
    t = t[:pointIndex] + t[pointIndex + 1:pointIndex + 4]
    return t


def readCookie():
    try:
        with open('tmp/cookie.txt', 'rb') as f:
            cookies = pickle.load(f)
            c = RequestsCookieJar()
            for k, v in cookies.items():
                c.set(k, v)
            return c
    except:
        return RequestsCookieJar()


def writeCookie(cookies):
    oldCookies = readCookie()
    for k, v in cookies.items():
        oldCookies.set(k, v)

    with open('tmp/cookie.txt', 'bw') as f:
        f.write(pickle.dumps(oldCookies))


def getVerifyCode():
    session.headers = config.Headers

    url = config.URLS.get('HOST') + config.URLS.get('GET_VERIFY_CODE')
    rsp = session.get(url, params={'t': getTimeStamp()})
    writeCookie(session.cookies)  # 写cookie
    data = rsp.content

    with open("tmp/code.jpg", 'bw') as f:
        f.write(data)

    headers = rsp.headers
    cookiestr = headers.get('Set-Cookie')
    cookies = [x.strip() for x in re.split(",|;", cookiestr) if x.strip().startswith('checkCode')]
    checkCode = ''
    for i in cookies:
        if '-' in i and len(i) > 20:
            checkCode = i.split('=')[1]
            break

    if test:
        with open('tmp/checkCode', 'w') as f:
            f.write(checkCode)

    return


def login(code=''):
    data = {
        'password': '05031ea9fd8981f9d5889e36f464088b',
        'loginSrc': '3',
        'deviceSn': '1a0018970a1983d77c4',
        'account': '15361431368',
        'valiCode': '',
        't': getTimeStamp()
    }

    if test:
        data['valiCode'] = code
    url = config.URLS.get('HOST') + config.URLS.get('LOGIN')

    session.headers = config.Headers
    session.headers['Content-Type'] = 'application/x-www-form-urlencoded'
    session.cookies = readCookie()
    for k, v in session.cookies.items():
        print(k, v)

    session.cookies.set('domain', 'www.ry399.com')
    session.cookies.set('path', '/')
    rsp = session.post(url + '?' + urlencode(data))
    print(rsp.request.headers)
    print(rsp.request.url)
    print(rsp.status_code)
    print(rsp.headers)

    rsp.encoding = 'utf-8'

    if rsp.status_code != 200:
        print('登录失败')
        return

    data = json.loads(rsp.text)
    config.UserInfo = data

